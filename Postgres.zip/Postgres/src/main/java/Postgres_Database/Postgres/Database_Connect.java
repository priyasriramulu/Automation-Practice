package Postgres_Database.Postgres;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.testng.annotations.Test;

public class Database_Connect {

	@Test
	public static void main( String[] args ) throws SQLException
    {
        Connection db = DriverManager.getConnection("jdbc:postgresql://hausgsgpa0138c/dvdrental", "postgres","postgres");
        Statement st = db.createStatement();
        System.out.println("am here ");
        ResultSet rs = st.executeQuery("Select * from dvdrental.public.actor where last_name ='Neeson'");
        List<String> a = new ArrayList<String> ();
        Map<String,String> m1 = new HashMap<String, String> ();
       while (rs.next())
        {
    	 String c1 = rs.getString(2)  ;
    	 String c2 = rs.getString(4);
    	 //int c2 = rs.
    	 a.add(rs.getString(2));
    	 m1.put(c1,c2);
    	 
    	   System.out.println(c1+" " );	
        }
              for (int i=0;i<a.size();i++)
       {
    	   System.out.println("array "+a.get(i));
       }
              a.add("");
              a.add("test");
              a.add("test");
              a.add("");
       m1.put("","");
       m1.put("s", "b");
       m1.put("","a");
       m1.put("", "b");
       m1.put("key","");
       m1.put("key","");
       m1.put("key2","");
       m1.put("s", "b");
       System.out.println(m1);
       Map<String,String> tm = new TreeMap<String,String>();
       tm.put("s","s");
       tm.put("","a");
       tm.put("s", "b");
       tm.put("","c");
       tm.put("", "");
       tm.put("key","");
       tm.put("key2","");
       tm.put("key","");
       tm.put("apple", "orange");
       System.out.println(tm);
       Set<String> ts = new TreeSet<String>(a);
       ts.add("testing");
       ts.add("testing");
       System.out.println("treeset"+ts);
       Set<String> hs = new HashSet<String>(a);
       
       hs.add("testing");
       hs.add("testing");
       
       System.out.println("Hashset"+hs);
      /* Set set = m1.entrySet();
       Iterator i = set.iterator();
       while(i.hasNext())
       {
    	   System.out.println("Map " +i.next());
    	   Map.Entry men = (Map.Entry)i.next();
    	   System.out.println(men.getValue());
       }*/
        rs.close();
        st.close();
    }

}
