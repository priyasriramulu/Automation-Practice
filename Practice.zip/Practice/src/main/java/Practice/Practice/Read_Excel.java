package Practice.Practice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.model.Sheet;
import org.apache.poi.hssf.model.Workbook;
import org.apache.poi.hssf.record.formula.functions.Row;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Read_Excel {

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		

		  File file = new File("D:/Personal/TestData/Output_file.xls");
		  //Create an object of FileInputStream class to read excel file

		  FileInputStream fi = new FileInputStream(file);
		  HSSFWorkbook ws = new HSSFWorkbook(fi);
		  HSSFSheet sh =ws.getSheet("output");
		  int row_count = sh.getLastRowNum();
		  System.out.println("row_Count:"+row_count);
		  for(int i=0;i<row_count;i++)
		  {
			  HSSFRow row = sh.getRow(i);
			  for(int j=0;j<row.getLastCellNum();j++)
			  {
				  System.out.println("Cell value is :"+row.getCell(j).toString());
			  }
		  }

		  
		  
	}

}
