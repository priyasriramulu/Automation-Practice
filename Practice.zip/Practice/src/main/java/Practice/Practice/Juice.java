package Practice.Practice;

public class Juice {

}
