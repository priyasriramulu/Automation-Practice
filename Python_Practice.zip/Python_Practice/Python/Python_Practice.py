from selenium import webdriver
from selenium.webdriver.common.keys import Keys

user = "sdsdd"
pwd = "sdsfdf"
driver = webdriver.Firefox()
driver.get("http://www.facebook.com")
assert "FF" in driver.title
elem = driver.find_element_by_id("email")
elem.send_keys(user)
elem = driver.find_element_by_id("pass")
elem.send_keys(pwd)
elem.send_keys(Keys.RETURN)
#driver.close()