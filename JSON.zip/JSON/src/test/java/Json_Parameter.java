import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;


public class Json_Parameter {

	public static void main(String[] args) throws JsonMappingException , IOException {
		// TODO Auto-generated method stub

		ObjectMapper mapper = new ObjectMapper();
		
		JsonNode node = mapper.readTree(new File("C:\\Users\\AU0003A7\\My Workspace\\JSON\\Test.json"));
		
		System.out.println(node.size());
		System.out.println(node.isArray());
		if(node.isArray())
		{
			for(int i=0;i<node.size();i++)
			{
				Map <String,String> map = new Hashtable<String,String>();
			ObjectReader reader = mapper.readerFor(new TypeReference<List<String>>() {});
			
		Iterator <String > itr = node.get(i).fieldNames();
		//System.out.println(node.get(i).fieldNames());
		while(itr.hasNext())
		{
			//System.out.println(itr.next());
			String key = itr.next();
			JsonNode value = node.get(i).findValue(key);
			if(value.isArray())
			{
				List<String> list = reader.readValue(value);
				String s="";
				for(String l : list)
				{
					s=s+l+",";
				}
				s=s.substring(0, s.length()-1);
				map.put(key, s);
			}
			else if (value.isObject())
			{
				Iterator<String> itr2 = value.fieldNames();
				while(itr2.hasNext())
				{
					String key2 = itr2.next();
					String  value2 = value.get(key2).toString();
				map.put(key2, value2);
				}
				
			}
			else
			{
				map.put(key, value.toString());
			}
		}
		//Map<> ht = new HashTable<>
		System.out.println("Final map"+map);
	}
	}
	}

}
