package Guru99.Guru99;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Table_Handling {
	
	//System.setProperty("webdriver.chrome.driver","C:\\Users\\AU0003A7\\My Workspace\\SG_Digital_Automation\\Drivers\\chromedriver.exe");
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.setProperty("webdriver.chrome.driver","C:\\Users\\AU0003A7\\My Workspace\\SG_Digital_Automation\\Drivers\\chromedriver.exe");
 WebDriver driver = new ChromeDriver();
 driver.get("https://money.rediff.com/gainers/bsc/daily/groupa");
 List<WebElement> ele =  driver.findElements(By.xpath("//table[@class='dataTable']//thead//tr//th"));
 int col = ele.size();
 System.out.println("Columns size:" +col);
 List<WebElement> ele_row = driver.findElements(By.xpath("//table[@class='dataTable']//tbody//tr"));
 int row = ele_row.size();
 System.out.println("Row size :"+row);
  ele_row = driver.findElements(By.tagName("tr"));
  row = ele_row.size();
  System.out.println("Row size using tag name:"+row);
 String s = driver.getWindowHandle();
 System.out.println(s);
 driver.findElement(By.xpath("//a[@href='//money.rediff.com/index.html\']")).click();
 String t = driver.getWindowHandle();

 System.out.println(t);
/*  for(int i=0;i<ele_row.size();i++)
  {
	  List<WebElement> col_row = ele_row.get(i).findElements(By.tagName("td"));
	  
	  for(int j=0;j<col_row.size();j++)
	  {
		  System.out.println("the value in row:"+i+ " and column: "+j+" "+ col_row.get(j).getText());
	  }
  }
	}*/
	
	}

}
