package Guru99.Guru99;

//import junit.framework.TestCase;

//public class Test extends TestCase {
	//public void test()
	//{
	//System.out.println("Hello World");
	//}
//}
