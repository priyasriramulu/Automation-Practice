package Guru99.Guru99;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import junit.framework.Assert;

public class TestNG_Practice {
	public String baseUrl = "http://demo.guru99.com/test/newtours/";
    String driverPath = "C:\\Users\\AU0003A7\\My Workspace\\SG_Digital_Automation\\Drivers\\chromedriver.exe";
    public static WebDriver driver ;
	@BeforeTest
	public void driver()
	{
		
	    System.out.println("launching firefox browser"); 
      //  System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        
       /* Assert.assertEquals("a", "a");
        Assert.fail();
        SoftAssert a = new SoftAssert();
        a.assertEquals("a", "a");
        a.assertAll();*/
	}
	public static void flash()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String bg = driver.findElement(By.xpath("")).getCssValue("backgroundcolor");
		//changeColor()
		
	}
  @Test (priority = 3)
  public void f() 
  {
	  driver.get(baseUrl);
	  //driver.manage().
	  SoftAssert a = new SoftAssert();
	  
	  a.assertEquals("true", "false");
	  Reporter.log("URL is accessed");
	  String expectedTitle = "Welcome: Mercury Tours";
      String actualTitle = driver.getTitle();
      Assert.assertEquals(actualTitle, expectedTitle);
      a.assertAll();
  }
  @Test 
  public void g()
  {
	 // driver.findElement(By.name("hello"));
	  throw new SkipException("Skipping");
  }
  @AfterTest
  public void terminateBrowser(){
      driver.close();
  }
}
